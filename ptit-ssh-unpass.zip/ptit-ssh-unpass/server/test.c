#include<stdio.h>
int main(){
	printf("done task!\n");
	return 0;
}
