#include<stdio.h>
#include<stdlib.h>
#include<string.h>
int main(){
int randomValue = rand();
char randomString[20];
printf("The secret number sequence is: %d\n", randomValue);
        printf("done task!\n");
        return 0;

}
